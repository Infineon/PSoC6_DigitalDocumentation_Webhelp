/*Maps current topic to its parent: "topicIndex:parentIndex". -1 represents the map.*/
var linkToParent = {9:22,18:22,0:-1,15:22,4:-1,22:-1,10:22,14:22,23:22,2:22,24:-1,3:22,20:22,25:22,16:4,13:22,26:-1,7:22,28:22,27:4,8:22,21:22,31:-1,12:22,19:22,6:-1,11:22,5:4,29:22};
