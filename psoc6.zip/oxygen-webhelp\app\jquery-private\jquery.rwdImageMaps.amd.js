define(["jquery", "jquery.rwdImageMaps"], function($, rwdImageMaps) {
    $.fn.rwdImageMaps = rwdImageMaps;
    return rwdImageMaps;
});